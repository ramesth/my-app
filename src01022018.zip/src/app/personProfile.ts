export class PersonProfile {
	name:String;
	age:Number;
	email:String;
	constructor(n:String,a:Number,e:String)
	
	{  this.name=n;
	   this.age=a;
	   this.email=e;
	}
}