
export class Person {
        name:String;
	constructor(
           
		n:String
	) {this.name=n }
}