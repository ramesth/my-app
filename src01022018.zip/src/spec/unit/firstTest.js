

describe ('when this test is executed by Karma', function (){
    it('this is a failed test', function (){
        expect(true).toBeFalsy();
    });
});