module.exports = {
    remoteUrl : 'mongodb://testmongocosmos:hpVdgd3uk6CwcrXoVuRgzvcNPxB5RGO2VpJjCMXhjvjeSs9IQEebgMRQSFGhH4oXxLP6FKs706VyEGOkpMSwQw==@testmongocosmos.documents.azure.com:10255/?ssl=true&replicaSet=globaldb',
    localUrl: 'mongodb://localhost'
};
